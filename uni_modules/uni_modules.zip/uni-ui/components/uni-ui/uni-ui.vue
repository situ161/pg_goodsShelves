<template>
	<view>占位组件，请勿使用</view>
</template>
<script>
</script>
<style>
</style>
