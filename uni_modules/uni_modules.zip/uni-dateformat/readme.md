

### DateFormat 日期格式化
> **组件名：uni-dateformat**
> 代码块： `uDateformat`


日期格式化组件。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-dateformat)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 